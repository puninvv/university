package hometasks.NonLinearEquations;

public interface Function {
    public double GetResult(double[] x);
}