package hometasks;

import hometasks.Matrixes.Matrix;
import hometasks.NonLinearEquations.NonLinearEquation;
import hometasks.NonLinearEquations.NonLinearSystem;
import hometasks.Integral.Integral;

public class HomeTasks {
    public static void main(String[] args) {
        //Matrix.HowToUse();
        //NonLinearEquation.HowToUse();        
        //NonLinearSystem.HowToUse();
        Integral.HowToUse();
    }
}
